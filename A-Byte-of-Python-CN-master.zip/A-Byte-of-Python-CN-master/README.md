简明 Python 教程
===
***waroop, C. H.*** *著*  ***沈洁元***  *译*

*www.byteofpython.info*


**版本：1.20**

*A Byte of Python*

 Copyright © 2003-2005 Swaroop C H
 
*简明 Python 教程*

《简明 Python 教程》为 "A Byte of Python" 的唯一指定简体中文译本，版权 © 2005 沈洁元
本书依照 [创作公用约定（署名-非派生作品-非商业用途）][ref_BY_ND_NC] 发布。

**概要**

无论您刚接触电脑还是一个有经验的程序员，本书都将有助您学习使用Python语言。


---
这本书原始的网站在这里： [简明 Python 教程][ref_A_byte_of_Python] , 我只是偶然想学习一下Python，在网上发现了它，一眼觉得这个教程挺好，遂在 `**GitHub** ` 上搜索，没有发现有人把他搬运到 `**GitHub** ` 上。就自己来了，一方面是自己在搬运过程中可以更仔细的阅读这份教程，另一方面最近来学习了 [Markdown][ref_markdown] 也想找点东西练手。

在搬运过程中，可能会疏忽的地方，如果你发现了，请告诉我或Fork it


[ref_markdown]: http://daringfireball.net/projects/markdown/
[ref_A_byte_of_Python]: http://woodpecker.org.cn/abyteofpython_cn/chinese/
[ref_BY_ND_NC]: http://www.creativecommons.org/licenses/by-nd-nc/1.0/deed.zh